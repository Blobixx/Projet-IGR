Informatique Graphique 3D et R�alit� Virtuelle 

Projet - Moteur de Rendu par Lancer de Rayon de Monte Carlo

Compilation : cd src; make -f Makefile.linux
Remplacer .linux par .cygwin pour une installation sous Windows/Cygwin. En fonction de votre environnment, le makefile doit �tre ajust�. 

Execution : ./my_ray_tracer <file.obj>

Contact: Tamy Boubekeur (tamy.boubekeur@telecom-paristech.fr)
